
import { test, expect, request } from '@playwright/test';

test.describe('API Tests for Music Tracks', () => {
  const baseUrl = 'https://testapi.io/api/rmstest/media';

  test('Scenario 1: Validate response status and time', async () => {
    const requestDate = new Date();
	const apiContext = await request.newContext();
    const response = await apiContext.get(baseUrl);

    // Validate HTTP status code
    expect(response.status()).toBe(200);
	const responseDate = new Date();
    // Validate response time
    expect(responseDate - requestDate).toBeLessThan(1000);
    });

  test('Scenario 2: Verify non-empty id and segment_type', async () => {
    const apiContext = await request.newContext();
    const response = await apiContext.get(baseUrl);
    const responseBody = await response.json();

    // Validate id field
    responseBody.data.forEach((item: any) => {
      expect(item.id).toBeTruthy();
      expect(item.segment_type).toBe('music');
    });
  });

  test('Scenario 3: Validate primary field in title_list', async () => {
    const apiContext = await request.newContext();
    const response = await apiContext.get(baseUrl);
    const responseBody = await response.json();

    // Validate title_list primary field
    responseBody.data.forEach((item: any) => {
      expect(item.title_list.primary).toBeTruthy();
    });
  });

  test('Scenario 4: Verify single now_playing track', async () => {
    const apiContext = await request.newContext();
    const response = await apiContext.get(baseUrl);
    const responseBody = await response.json();

    const nowPlayingTracks = responseBody.data.filter((item: any) => item.offset.now_playing);
    expect(nowPlayingTracks.length).toBe(1);
  });

  test('Scenario 5: Validate Date header', async () => {
    const apiContext = await request.newContext();
    const response = await apiContext.get(baseUrl);

    const dateHeader = response.headers()['date'];
	expect(new Date(dateHeader).toString()).not.toBe('Invalid Date');
    });
});
        